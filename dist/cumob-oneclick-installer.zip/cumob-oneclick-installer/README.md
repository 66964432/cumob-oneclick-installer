# CUMOB 一键安装器：Codex + Claude Code

[English](README.en.md)

macOS / Windows 双击入口可安装 Codex；Bash 安装脚本同时支持 Codex 和 Claude Code，并安装最新的 `cumob-media-generation` Skill。

> 安装器会检测本机客户端，并让你选择 **Codex**、**Claude Code** 或 **两者都装**。使用 `--no-prompt` 时会自动为检测到的客户端安装。

安装后自动完成：

1. 安装最新 `cumob-media-generation` Skill
2. 写入 CUMOB provider 配置
3. 配置 CUMOB 远端模型目录 `/v1/codex/models`
4. 将 CUMOB API Key 合并进 Codex `auth.json`
5. 支持选择为 Codex 或 Claude Code（或同时）安装

## 设计目标

- **Codex：** 配置 CUMOB provider、模型目录、权限策略和 `auth.json`，并安装 Skill。
- **Claude Code：** 配置 `settings.json` 中的 CUMOB / OpenAI-compatible 环境变量，安装 Skill，并创建 `/cumob-media` 命令。
- 用户只需要下载很小的安装入口，双击即可；安装时从 GitHub 拉取最新 Skill 和配置模板，并从 CUMOB 认证接口读取模型目录。安装完成后可以删除安装器本地副本。
- 不打包真实 API Key。
- 重复安装可升级，并在覆盖 Codex 文件前自动备份；Claude Code 已有 Skill 目录也会先改名备份。

## 仓库

- 安装器：[`66964432/cumob-oneclick-installer`](https://github.com/66964432/cumob-oneclick-installer)
- Skill：[`66964432/cumob-media-generation`](https://github.com/66964432/cumob-media-generation)
- 最新发布页：https://github.com/66964432/cumob-oneclick-installer/releases/latest

## 客户端支持

| 客户端 | 自动配置内容 | 默认目录 |
| --- | --- | --- |
| OpenAI Codex | CUMOB provider、模型目录、`config.toml`、`auth.json`、Skill | `~/.codex` |
| Claude Code | `settings.json` 环境变量、Skill、`/cumob-media` 自定义命令 | `~/.claude` |

### Codex

Codex 安装会写入或更新：

- `config.toml` 中的 CUMOB provider、默认模型和模型目录；
- `auth.json` 中的 `OPENAI_API_KEY`；
- `skills/cumob-media-generation/` 及图片 / 视频脚本。

### Claude Code

Claude Code 安装会：

- 合并或创建 `settings.json`，保留原有设置，并写入 `CUMOB_API_KEY`、`CUMOB_BASE_URL`、`OPENAI_API_KEY` 和 `OPENAI_BASE_URL`；
- 将 `cumob-media-generation` 安装到 `skills/cumob-media-generation/`；
- 创建 `commands/cumob-media.md`，可在 Claude Code 中使用 `/cumob-media` 快速调用图片 / 视频 Skill；
- 如果检测到 `claude` CLI，会优先尝试 `claude plugin install`，失败后自动回退到本地复制安装。

> Claude Code 的 API Key 会写入 `settings.json` 的环境变量配置；请像保护其他本地密钥一样保护该文件。

## 安装前准备

1. 已安装 [Codex](https://chatgpt.com/codex) 和/或 [Claude Code](https://docs.anthropic.com/en/docs/claude-code)
2. 电脑可访问 GitHub 和所选 CUMOB HTTPS 端点；Codex 需要支持 `model_catalog_url` 和 API Key 模型发现
3. 准备好你的 CUMOB API Key（见下方「如何获取 CUMOB API Key」）
4. 图片 / 视频生成建议准备 Node.js 18+ 或 Python 3；Windows 缺少运行时时安装器可自动安装 Node.js LTS

## 如何获取 CUMOB API Key

安装器本身不提供密钥，需要先到 CUMOB 平台（https://api.cumob.com）注册 / 登录后自行创建。

### 平台与域名

| 用途 | 域名 |
| --- | --- |
| 平台入口（获取密钥、账户管理） | [https://api.cumob.com](https://api.cumob.com) |
| API 接入（环太平洋） | `https://api.cumob.com/v1` |
| API 接入（东亚地区） | `https://api.cumob.cn/v1` |

说明：

- 用户访问与密钥管理请打开：https://api.cumob.com
- 安装器里的 `base_url` 使用 API 接入地址：`https://api.cumob.com/v1` 或 `https://api.cumob.cn/v1`
- 平台入口与 Codex 调用都走 CUMOB 域名；安装时按提示选择 `.com` / `.cn` 线路即可

### 推荐步骤

1. 打开 [CUMOB 平台](https://api.cumob.com)
2. 注册账号，或使用已有账号登录
3. 在 API Key 页面中创建 / 复制 API Key
4. 回到本安装器，按提示粘贴该 Key
5. 如需切换线路，安装时可选择：
   - `1` → `https://api.cumob.com/v1`（默认）
   - `2` → `https://api.cumob.cn/v1`

如果平台页面里的菜单名称与上述描述不完全一致，以控制台实际文案为准；只要能创建并复制 API Key 即可。

## 一键安装（推荐）

> **客户端实现差异：** `install.sh` 支持 Codex / Claude Code / 两者同时安装。Windows 的 `install-windows.cmd` / `install.ps1` 当前负责 Codex 配置和 Windows 图片运行时；Windows 用户如需安装 Claude Code，请在 Git Bash 或 WSL 中运行 `bash install.sh`。

### macOS

1. 下载：[`install-macos.command`](https://github.com/66964432/cumob-oneclick-installer/releases/latest/download/install-macos.command)
2. 双击运行
3. 如果系统提示“无法打开”，请：
   - 右键文件 → 选择“打开”
   - 或到“系统设置 → 隐私与安全性”中允许运行
4. 按提示输入 CUMOB API Key
   - 输入时不会显示字符，属正常现象
   - 如果本机已配置过 Key，可直接回车跳过
6. 看到 `Installation finished` 后，关闭窗口
7. 重启 Codex / Claude Code，或新建一个任务

### Windows

1. 下载：[`install-windows.cmd`](https://github.com/66964432/cumob-oneclick-installer/releases/latest/download/install-windows.cmd)
2. 双击运行
3. 如果 SmartScreen 拦截，选择“仍要运行”
4. 按提示选择 Codex / Claude Code / 两者都装
5. 按提示输入 CUMOB API Key
   - 输入时不会显示字符，属正常现象
   - 如果本机已配置过 Key，可直接回车跳过
6. 看到 `Installation finished` 后，按任意键关闭窗口
7. 重启 Codex，或新建一个任务

Parallels 的 `\\Mac\...` 共享目录也可直接运行；启动器会临时映射盘符，以兼容 CMD 不支持 UNC 当前目录的限制。

即使只下载入口文件，安装器也会从 GitHub 拉取：

- 最新安装逻辑
- 最新配置模板
- 最新 Skill

最快安装流程：

**下载入口 → 双击安装 → 选择客户端 → 输入 API Key → 重启客户端**

## 从源码安装

macOS / Linux：

```bash
git clone https://github.com/66964432/cumob-oneclick-installer.git
cd cumob-oneclick-installer
bash install.sh
```

Windows PowerShell：

```powershell
git clone https://github.com/66964432/cumob-oneclick-installer.git
cd cumob-oneclick-installer
.\install.ps1
```

## 安装后会写入什么

默认写入位置：

- 优先使用环境变量 `CODEX_HOME`
- Windows 生图脚本还会从已安装 skill 路径反推 Codex home
- 未设置时：
  - macOS：`~/.codex`
  - Windows：`%USERPROFILE%\.codex`
- 受限 shell 仍解析失败时，可显式传 `--codex-home`

写入内容：

```text
<CODEX_HOME>/
├── auth.json
├── config.toml
├── skills/
│   └── cumob-media-generation/
└── backups/
    └── cumob-installer-YYYYMMDD-HHMMSS/

<CLAUDE_HOME>/
├── settings.json
├── skills/
│   └── cumob-media-generation/
└── commands/
    └── cumob-media.md
```

安装器会按所选客户端配置：

- 最新 `cumob-media-generation` Skill；
- CUMOB 模型目录和 provider 配置（Codex）；
- CUMOB API Key（Codex 写入 `auth.json`，Claude Code 写入 `settings.json` 的环境变量）；
- Claude Code 的 `/cumob-media` 命令（如果选择 Claude Code）。

## 如何确认安装成功

按所选客户端检查：

**Codex**

1. 模型列表里能看到 CUMOB 模型，例如 `gpt-5.6-sol`；
2. 可以调用媒体 Skill：`cumob-media-generation`；
3. 生成图片时不再提示缺少 API Key / provider。

**Claude Code（使用 `install.sh` 安装时）**

1. `~/.claude/settings.json` 中存在 CUMOB 环境变量；
2. `~/.claude/skills/cumob-media-generation/SKILL.md` 存在；
3. 可以使用 `/cumob-media` 命令。

## 升级

以后如果 Skill 或配置有更新：

1. 再次双击同一个安装入口
2. 安装器会重新拉取最新版本并覆盖升级
3. 你的其他 Codex 配置会保留
4. 旧文件会自动备份

## 配置策略

安装器不会整文件覆盖 `config.toml`。它会：

- 先备份旧配置、旧 auth、旧模型目录、旧 Skill
- 升级时备份并移除旧名称 `cumob-image-generation4codex`，避免两个 Skill 并存
- 删除旧的 CUMOB provider 段和本安装器受管段
- 写入随所选域名生成的 `model_catalog_url`，移除顶层 `model_catalog_json`，启用 API Key 模型发现
- 旧本地目录文件若存在则备份保留，不再引用；发现影响 CUMOB 的 profile 覆盖配置时在修改前退出并提示
- 保留其他 provider / MCP / 插件 / 桌面设置 / 项目权限
- 重复运行时升级，不产生重复 TOML 键

受管配置默认值：

```toml
model_provider = "cumob"
model = "gpt-6-astra"
disable_response_storage = true
model_reasoning_effort = "high"

[model_providers.cumob]
name = "cumob"
wire_api = "responses"
image_api = "images"
image_model = "gpt-image-2.5"
video_api = "videos"
video_model = "minimax-h3-2k"
requires_openai_auth = true
base_url = "https://api.cumob.com/v1"
model_catalog_url = "https://api.cumob.com/v1/codex/models"

[features]
api_key_model_discovery = true
```

### 远端模型目录与升级

- Codex 的目录来源为所选 CUMOB 域名下的 `/v1/codex/models`；请求会携带当前 provider 的认证信息。安装器不会把 API Key 发往 GitHub 或跟随目录接口重定向。
- `payload/cumob-models.json` 保留为服务端维护 / 发布参考文件，安装器不再读取或复制它。你需要让服务端发布流程把修改后的清单实际提供给该接口；只提交 GitHub 不会自行更新服务端。
- 安装时先使用本次输入或现有 `auth.json` 中的 `OPENAI_API_KEY` 验证接口，再从可见且支持 API 的模型中按最低 `priority` 选取初始 `model` 和 `model_reasoning_effort`。示例中的模型名是示意值，以接口返回值为准。
- 没有有效凭据、HTTP 错误、超时、重定向、超过 1 MiB、无效 JSON 或无可用默认模型时，安装器在改写 Codex 配置、认证和 Skill 前退出；不会退回预置清单。
- 安装后由 Codex 原生获取目录，刷新时机与缓存遵循客户端机制。服务端新增 / 下架模型后重启 Codex 验证列表，不需要保留安装器或安装系统定时任务。
- 列表更新不自动改写用户的 `model`、推理等级或已有会话。服务端若下架当前模型，用户仍需选择可用模型；重新运行安装器会重新选择初始默认值。
- 升级旧安装时必须移除生效的 `model_catalog_json`，否则它会阻止远程获取。安装器清理顶层旧设置；影响 CUMOB 的 profile 覆盖项会明确报错并保留原配置，其他 provider 的 profile 保留。
- 原生 `[features]` 表中的其他设置会保留。为避免损坏 TOML，内联 `features = {...}` 或除发现开关外的顶层点号 features 配置需要先整理成 `[features]` 表。
- 使用支持此功能的新版 Codex；不会给旧版静默配置本地目录。无法自动识别客户端版本时接口需提供默认目录，也可设置 `CUMOB_CODEX_CLIENT_VERSION=0.162.1` 指定实际的 `major.minor.patch` 版本。
- 旧 `CUMOB_MODELS_URL` 选项已移除。目录地址始终由所选 CUMOB `base_url` 派生，不支持把凭据发送到任意自定义目录地址。

图片模型和视频模型属于 provider 配置，仍分别由 `payload/cumob-config.template.toml` 中的 `image_model` 和 `video_model` 管理。

`base_url` 支持 `https://api.cumob.com/v1` 与 `https://api.cumob.cn/v1`。两个域名都有效。

- 安装时交互选择端点：`1 = https://api.cumob.com/v1`（默认），`2 = https://api.cumob.cn/v1`
- 15 秒内无操作，自动选择默认 `.com`
- `--no-prompt` / 非交互安装直接使用默认 `.com`
- 也可通过环境变量强制指定并跳过选择：`CUMOB_BASE_URL=https://api.cumob.cn/v1`
- 生图脚本始终读取 Codex provider 的 `base_url`，不会写死域名

## 安全

- 发行包与仓库都不包含真实 API Key
- API Key 不作为命令行参数传递，也不会写入安装日志
- Codex 新 Key 只写入 `auth.json` 的 `OPENAI_API_KEY`；
- Claude Code 新 Key 写入 `settings.json` 的 `CUMOB_API_KEY` 和 `OPENAI_API_KEY`；
- 现有其他 auth / settings 字段会保留；
- 不输入 Key 时，保留已有认证信息。

非交互安装：

```bash
CUMOB_INSTALL_API_KEY="your-key" bash install.sh --no-prompt
```

```powershell
$env:CUMOB_INSTALL_API_KEY = "your-key"
.\install.ps1 -NoPrompt
Remove-Item Env:CUMOB_INSTALL_API_KEY
```

## 高级选项

只预览，不改文件：

```bash
bash install.sh --dry-run
```

```powershell
.\install.ps1 -DryRun
```

自定义 Codex / Claude Code 目录：

```bash
CODEX_HOME="/custom/codex" CLAUDE_HOME="/custom/claude" bash install.sh
```

```powershell
$env:CODEX_HOME = "D:\CodexHome"
$env:CLAUDE_HOME = "$env:USERPROFILE\.claude"
.\install.ps1
```

非交互安装会自动检测客户端；也可以先运行：

```bash
bash install.sh --dry-run
```

自定义远程源：

```bash
export CUMOB_INSTALLER_URL="https://github.com/66964432/cumob-oneclick-installer/archive/refs/heads/main.zip"
export CUMOB_SKILL_URL="https://github.com/66964432/cumob-media-generation/archive/refs/heads/main.zip"
bash install.sh
```

Windows 图片运行时控制：

```powershell
# 跳过自动安装 Node.js，仅保留 PowerShell 后备
$env:CUMOB_SKIP_NODE_INSTALL = "1"
.\install.ps1 -NoPrompt

# 自定义 Node 安装目录 / 下载源
$env:CUMOB_NODE_INSTALL_DIR = "$env:LOCALAPPDATA\my-cumob-node"
$env:CUMOB_NODE_DIST_URL = "https://nodejs.org/dist/v22.14.0/node-v22.14.0-win-x64.zip"
.\install.ps1 -NoPrompt
```

## 常见问题

### 1. 安装失败，提示网络错误

请确认：

- 能打开 GitHub
- 没有被公司代理 / 防火墙拦截
- 可访问：
  - `https://github.com/66964432/cumob-oneclick-installer`
  - `https://github.com/66964432/cumob-media-generation`

然后重新双击安装。

### 2. 安装成功，但客户端里看不到变化

请：

1. 完全退出 Codex / Claude Code 再打开；
2. 或新建一个任务；
3. Codex 检查模型列表和 Skill，Claude Code 检查 `/cumob-media` 命令和 Skill。

### 3. API Key 从哪里获取？

打开 CUMOB 平台：https://api.cumob.com  
登录后创建 / 复制 API Key，再运行安装器填入。详细步骤见上文「如何获取 CUMOB API Key」。

### 4. API Key 输错了怎么办

再次运行安装入口，重新输入正确 Key 即可。

### 5. 会不会覆盖我原来的 Codex / Claude Code 配置？

不会整份覆盖。安装器只会：

- 更新 CUMOB 相关配置；
- 保留其他 Codex provider / 插件 / 桌面设置；
- 合并 Claude Code 的 `settings.json.env`；
- 在替换前备份 Codex 文件，并为已有 Claude Code Skill 目录创建 `.bak.YYYYMMDD-HHMMSS` 备份。

Codex 备份目录：

- macOS：`~/.codex/backups/`
- Windows：`%USERPROFILE%\.codex\backups\`

Claude Code 备份：

- 已有 Skill：`~/.claude/skills/cumob-media-generation.bak.YYYYMMDD-HHMMSS/`

## 运行要求

- 已安装 Codex 和/或 Claude Code；
- 网络可访问 GitHub；
- macOS / Linux 需要 Bash、curl、unzip，以及 Node.js 18+ 或 Python 3；
- Windows PowerShell 入口当前配置 Codex；Windows 上安装 Claude Code 请使用 Git Bash 或 WSL 运行 `bash install.sh`；
- Claude Code CLI `claude` 可选：存在时安装器会优先尝试插件安装，失败会自动回退；
- 图片 Skill 优先使用 Node.js 18+ 或 Python 3
- Windows 安装器会自动检测运行时：
  - 已有 Node.js 18+ 或 Python 3：直接复用
  - 两者都没有：默认从 nodejs.org 下载 Node.js LTS，安装到 `%LOCALAPPDATA%\cumob-nodejs`，并写入当前进程 PATH 与用户 PATH
  - 如需跳过自动安装：设置 `CUMOB_SKIP_NODE_INSTALL=1`
  - 可选覆盖：`CUMOB_NODE_DIST_URL`、`CUMOB_NODE_INDEX_URL`、`CUMOB_NODE_INSTALL_DIR`
- Windows 仍保留 PowerShell 5.1 后备脚本，仅在 Node/Python 不可用时应急使用
- macOS / Linux 的图片 Skill 仍需 Node.js 18+ 或 Python 3

Windows 安装后，Skill 中会增加统一启动器：

```powershell
& "$env:USERPROFILE\.codex\skills\cumob-media-generation\scripts\generate-image-windows.cmd" `
  --prompt "A quick test image" `
  --out "$env:TEMP\cumob-test.png" `
  --dry-run
```

该启动器会自动读取 Codex 的 CUMOB 配置和 `auth.json`，优先调用 Node.js / Python，必要时才使用内置 PowerShell 后备脚本。

## 开发与验证

macOS / Linux：

```bash
bash tests/test-install.sh
```

目录预检与 TOML 合并测试（开发 / CI 使用 Python 3.11+）：

```bash
python3 tests/test-remote-catalog.py
```

Windows：

```powershell
.\tests\test-install.ps1
```

Skill 联网验证（模型接口仍使用离线 fixture，不消耗真实 API 凭据）：

```bash
CUMOB_LIVE_TEST=1 bash tests/test-install.sh
```

构建本地发布包：

```bash
bash build-release.sh
```

## 仓库结构

```text
cumob-oneclick-installer/
├── install-macos.command
├── install-windows.cmd
├── install.sh
├── install.ps1
├── payload/
│   ├── cumob-config.template.toml
│   ├── cumob-models.json  # 服务端发布参考，不安装到客户端
│   ├── generate-image.ps1
│   └── generate-image-windows.cmd
├── scripts/
├── tests/
├── .github/workflows/
├── README.md
├── README.en.md
└── SOURCE.json
```

用户只需运行一次安装入口。安装逻辑和 Skill 从 GitHub 发布，模型目录由 CUMOB 接口持续提供。
